#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#ifndef MAP_H
  #define MAP_H
#include "playerchoice.h"

int
remplissage_case (int *p0, int *p1, int *p2, int *p3, int *p4, int *p5, int *p6, int *p7, int *p8, int *p9, int *p10)
{//


 int a;
  do {
      a = rand () % 11;
      a=a+3;
      switch (a)
        {
        case 3: //portail
          if (*p0 < 1)
          {
            *p0 += 1;
            return a;
          }
          break;
        case 4://totems
          if (*p1 < 2)
          {
            *p1 += 1;
            return a;
          }
          break;
        case 5: // Trésors
          if (*p2 < 2)
          {
            *p2 += 1;
            return a;
          }
          break;
        case 6: //arme legendaire guerrier
          if (*p3 < 1)
          {
            *p3 += 1;
            return a;
          }
          break;
        case 7://arme legendaire archer
          if (*p4 < 1)
          {
            *p4 += 1;
            return a;
          }
          break;
        case 8://arme legendaire voleur
          if (*p5 < 1)
          {
            *p5 += 1;
            return a;
          }
          break;
        case 9://arme legendaire magicien
          if (*p6 < 1)
          {
            *p6 += 1;
            return a;
          }
          break;
        case 10: //Basilic
          if (*p7 < 4)
          {
            *p7 += 1;
            return a;
          }
          break;
        case 11://Zombie
          if (*p8 < 4)
          {
            *p8 += 1;
            return a;
          }
          break;
        case 12:// Trolls
          if (*p9 < 4)
          {
            *p9 += 1;
            return a;
          }
          break;
        case 13://Harpies
          if (*p10 < 4)
          {
            *p10 += 1;
            return a;
          }
          break;
        }
    } while (1);
  return 0;
}

void
affichemap (card tab[][7])
{
  for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
          switch (tab[i][j].type){
                case 5:
                printf ("    \033[1;33m♕\033[0m");
              break;
                case 4://totems
                printf("    \033[1;34m☨\033[0m");
              break;
                case 3://portail
                printf ("    \033[1;34m♢\033[0m");
              break;
                case 6://arme legendaire guerrier
                printf("    ⚔️");
              break;
                case 7://al archer
                printf("   🔫");
              break;
                case 8://al voleur
                printf("   🔪");
              break;
                case 9://al magicien
                printf("   📜");
              break;
                default:
                 printf ("%5d", tab[i][j].type);
              }
          
        }
   printf ("\n");
    }
}

void
affichemap2 (card tab[][7])
{
  for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
          if (tab[i][j].status == 1){
              switch (tab[i][j].type){
                case 5:
                printf ("    \033[1;33m♕\033[0m");
              break;
                case 4://totems
                printf("     \033[1;34m☨\033[0m");
              break;
                case 3://portail
                printf ("    \033[1;34m♢\033[0m");
              break;
                case 6://arme legendaire guerrier
                printf("    ⚔️");
              break;
                case 7://al archer
                printf("   🔫");
              break;
                case 8://al voleur
                printf("   🔪");
              break;
                case 9://al magicien
                printf("   📜");
              break;
                default:
                 printf ("%5d", tab[i][j].type);
              }
                
        } else if (tab[i][j].status == 2){
            printf("     ");
          }
        else{
            printf ("    X");
        }
        }
   printf ("\n");
    }
}

void
affichemap3 (adventurer* pa,card tab[][7])
{
  for (int i = 0; i < 7; i++)
    {
        for (int j = 0; j < 7; j++)
        {
          if ((*pa).position.rows==i && (*pa).position.cols==j){
            printf ("\033[1;35m    #\033[0m");
            
            } else if(tab[i][j].status == 1){
             
              switch (tab[i][j].type){
                case 5:
                printf ("    \033[1;33m♕\033[0m");
              break;
                case 4://totems
                printf("     \033[1;34m☨\033[0m");
              break;
                case 3://portail
                printf ("    \033[1;34m♢\033[0m");
              break;
                case 6://arme legendaire guerrier
                printf("    ⚔️");
              break;
                case 7://al archer
                printf("   🔫");
              break;
                case 8://al voleur
                printf("   🔪");
              break;
                case 9://al magicien
                printf("   📜");
              break;
                default:
                 printf ("%5d", tab[i][j].type);
                
              }
        
          
          
          } else if (tab[i][j].status == 2){
            printf("     ");
          } else{
            printf ("    X");
        }
        }
   printf ("\n");
    }
}

#endif 