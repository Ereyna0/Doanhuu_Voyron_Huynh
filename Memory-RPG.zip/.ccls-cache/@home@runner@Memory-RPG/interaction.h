#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#ifndef INTERACTION_H
  #define INTERACTION_H
#include "playerchoice.h"

void mort (adventurer *pa) { // reset sa position initiale, le joueur meurt 
  printf("Vous êtes mort... Next \n");
(*pa).etat = 0; 
(*pa).position.rows = (*pa).spawn.rows;
(*pa).position.cols = (*pa).spawn.cols;
(*pa).treasure=0;
(*pa).legendary=0; 
/* la valeur du pointeur si je mets seulement a.position.rows le pc ne reconnaît pas */
}

void tp(adventurer *pa, card tab[][7]){
int x=0;
int y=0; // on initialise x et y des coord à 0 pour que la boucle se lance à coup sûr une première fois
printf ("Vous êtes tombé sur un \033[42m portail \033[0m\n, choisissez les coordonnées de la case où vous souhaitez aller ! \n");
printf("\n");


tab[(*pa).position.rows][(*pa).position.cols].status=1;

printf("(%d;%d)",(*pa).position.rows,(*pa).position.cols);

do {

  do { 
printf("Veuillez entrer des coordonnées valables: à l'intérieur de la zone de jeu et sur des cases faces cachées\n");
printf("\n");
printf ("saisir la ligne \n");
scanf ("%d",&x);
printf("\n");
printf ("saisir la colonne \n");
scanf ("%d",&y);
printf("\n");
  }while(x<1||x>5||y<1||y>5); 
}while(tab[x][y].status==1);


printf("(%d;%d)",x,y);
printf("\n");
(*pa).position.rows=x;
(*pa).position.cols=y;

printf("(%d;%d)",(*pa).position.rows,(*pa).position.cols);
  
}

void totem (adventurer *pa, card tab[][7]){

int x=0;
int y=0;
int temp; // VARIABLE TEMPORAIRE TEMP

printf("Vous avez découvert un totem de transmutation. Choisissez les coordonnées de la case choisie qui échangera de position avec le totem.");

do{
printf ("\n");
do { 
printf ("\n");
printf("Veuillez entrer des coordonnées valables: à l'intérieur de la zone de jeu et sur des cases faces cachées. Attention : il est impossible de transmuter une case devant la position initiale des joueurs ! \n");
printf("\n");
printf ("saisir la ligne \n");
scanf ("%d",&x);
printf("\n");
printf ("saisir la colonne \n");
scanf ("%d",&y);
printf("\n");
  }while(x<1||x>5||y<1||y>5); 
}while(tab[x][y].status==1 || (x==1&&y==4) || (x==4&&y==5) || (x==2&&y==1) || (x==5&&y==3)); // tant que ce n'est pas une face cachée et que cela ne se trouve pas devant la position initiale d'un joueur 

  
temp=tab[(*pa).position.rows][(*pa).position.cols].type;
tab[(*pa).position.rows][(*pa).position.cols].type=tab[x][y].type;
tab[x][y].type=temp; // échange totem avec la case choisie qui reste face cachée 

}

void interaction(adventurer* pa, card tab[7][7]){

// on utilise le pointeur pour désigner le joueur, sinon le programme ne reconnaît pas 

switch(tab[(*pa).position.rows][(*pa).position.cols].type){ // pa est le pointeur sur l'adventurier 

case 10:
    printf("Vous avez rencontré un \033[1;31m Basilic \033[0m\n \n");
      if ((*pa).arme==1){
        (*pa).killcount+=1;
        printf ("Vous avez vaincu le \033[1;31m Basilic \033[0m\n \n");
      }
      else{
      mort(pa);
    }
  break;
case 11:
    printf("Vous avez rencontré un \033[1;31m Zombie \033[0m\n \n" );
      if ((*pa).arme==2){
        (*pa).killcount+=1;
      printf ("Vous avez vaincu le \033[1;31m Zombie\033[0m\n \n");
      }
      else{
      mort(pa);
    }
  break;
case 12:
    printf("Vous avez rencontré un \033[1;31m Troll\033[0m\n \n");
      if ((*pa).arme==3){
        (*pa).killcount+=1;
      printf ("Vous avez vaincu le \033[1;31m Troll\033[0m\n \n");
      }
      else{
        mort(pa);
      }
  break;
case 13:
    printf("Vous avez rencontré une \033[1;31m Harpie\033[0m\n \n");
      if ((*pa).arme==4){
        (*pa).killcount+=1;
      printf ("Vous avez vaincu la \033[1;31m Harpie \033[0m\n  \n");
      }

      else{
      mort(pa); 
        }      
break;
case 6:
   printf ("Vous avez trouvé \033[44m l'épée de feu \033[0m\n \n");
  if ((*pa).classe==1) {
    (*pa).legendary+=1;
  printf ("Vous avez équipé \033[44m l'épée de feu \033[0m\n \n");
  }
break;
case 7:
   printf ("Vous avez trouvé \033[44m l'arc légendaire\033[0m\n \n");
  if ((*pa).classe==2) {
    (*pa).legendary+=1;
  printf ("Vous avez équipé \033[44m l'arc légendaire\033[0m\n \n");
  }
break;
case 8:
   printf ("Vous avez trouvé \033[44m la dague de sommeil\033[0m\n \n");
  if ((*pa).classe==3) {
    (*pa).legendary+=1;
  printf ("Vous avez équipé \033[44m la dague de sommeil\033[0m\n \n");
 }
break;
case 9:
   printf ("Vous avez trouvé \033[44m le grimoire légendaire\033[0m\n \n");
  if ((*pa).classe==4) {
    (*pa).legendary+=1;
 printf ("Vous avez équipé \033[44m le grimoire légendaire\033[0m\n \n");
  }
break;
case 3:
  
  tp(pa, tab);
  interaction(pa,tab); 
break;
case 4:
  totem(pa, tab);
  printf ("En échange de son utilisation, le \033[42m totem \033[0m\n  aspire votre force vitale...");
  mort(pa);
break;
case 5: 
printf ("vous avez trouvé un \033[1;33m coffre\033[0m\n ! \n");
(*pa).treasure+=1;
break;
default:
  exit (1); // termine le programme
  }
}

#endif