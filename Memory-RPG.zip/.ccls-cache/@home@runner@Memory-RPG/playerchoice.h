#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#ifndef PLAYERCHOICE_H
  #define PLAYERCHOICE_H

void vide_buffer(){
  while (getchar()!='\n'){
  }
}


typedef struct {
  int status; // 0=face cachée, 1=face ouverte, 2=case vide
  int type;
} card;
int choix_arme() {
int a=0;
do{ 
printf ("Veuillez choisir une arme disponible :\n 1 - Bouclier \n 2 - Torche \n 3 - Hache \n 4 - Arc \n");

scanf ("%d",&a);
vide_buffer();
}while (a<=0||a>=5);
return a;
}




typedef struct { 
    int rows ;
    int cols;
} coordonnee;

typedef struct{
    int numeroj; //numero du joueur
    char nom[20]; //chaine caractère
    int classe; // 20=> Guerrier, 30 =>Archer, 40 => prêtre, 50 => mage
    char classenom[15]; //chaine caractère
    int arme; 
    int etat; //1 --> en vie; 0 --> mort , 2 --> win
    coordonnee position;
    coordonnee spawn;
    int killcount; 
    int legendary; //arme légendaire
    int treasure; //treasure count
} adventurer;

void affiche_adventurer(adventurer a) {
    printf ("%s\n", a.nom);
    printf("Vous êtes le joueur n°%d\n", a.numeroj);
    printf("%s\n", a.classenom);
    printf("%d\n", a.classe);
    printf("%d\n", a.arme);
    printf("%d\n\n", a.etat);
    printf("Vous vous trouvez à la position (%d;%d) \n", a.position.rows,
         a.position.cols);
    printf("Spawn du %s : (%d;%d) \n", a.classenom, a.spawn.rows, a.spawn.cols);
    printf("Monstres tués : %d\n", a.killcount);
    printf("Arme légendaire en possession : %d\n", a.legendary);
    printf("Trésor(s) trouvé(s) : %d\n \n", a.treasure);
}

void directionchoix(adventurer* pa, card tab[][7]){
    int z;
  
    printf ("Saisir un direction possible sans sortir de la carte :\n Haut[8] Gauche [4] Droite[6] Bas[2]\n");
    scanf("%d",&z);
    vide_buffer();
    if (z==4){
        (*pa).position.cols-=1;
        if ((*pa).position.cols<1||(*pa).position.rows<1||(*pa).position.rows>5){
          (*pa).position.cols+=1;
          printf ("Vous vous êtes pris un mur : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa,tab);
        }
        if(tab[(*pa).position.rows][(*pa).position.cols].status!=0){
          (*pa).position.cols+=1;
          printf ("Vous avez déjà visité cette pièce : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
      
    }
    else if (z==8){
        (*pa).position.rows-=1;
        if ((*pa).position.rows<1 ||(*pa).position.cols<1 ||(*pa).position.cols>5){
          (*pa).position.rows+=1;
          printf ("Vous vous êtes pris un mur : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa,tab);
        }
        if(tab[(*pa).position.rows][(*pa).position.cols].status!=0){
          (*pa).position.rows+=1;
          printf ("Vous avez déjà visité cette pièce : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
    }
    else if (z==6){
        (*pa).position.cols+=1;
        if ((*pa).position.cols>5||(*pa).position.rows<1||(*pa).position.rows>5){
          (*pa).position.cols-=1;
          printf ("Vous vous êtes pris un mur : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
        if(tab[(*pa).position.rows][(*pa).position.cols].status!=0){
          (*pa).position.cols-=1;
          printf ("Vous avez déjà visité cette pièce : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
    }
    else if (z==2){
        (*pa).position.rows+=1;
        if ((*pa).position.rows>5||(*pa).position.cols<1||(*pa).position.cols>5){
          (*pa).position.rows-=1;
          printf ("Vous vous êtes pris un mur : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
      if(tab[(*pa).position.rows][(*pa).position.cols].status!=0){
          (*pa).position.rows-=1;
          printf ("Vous avez déjà visité cette pièce : Impossible de se diriger dans ce sens là \n");
          directionchoix(pa, tab);
        }
    }
    else{
        printf ("resaisir une direction disponible ");
        directionchoix(pa,tab);
    }
  
  
}


adventurer creat_player(int i, int* compteur ) {
    adventurer a;

    a.numeroj=i;
    printf ("Veuillez insérer le nom du joueur\n");
    scanf("%s", a.nom);
    printf ("Veuillez choisir un numéro de classe : Guerrier [1], Archer [2], Voleur [3], Magicien [4]\n");
    scanf ("%d",&a.classe);
    vide_buffer();
    while (a.classe<1||a.classe>4) {
        printf ("Resaisir une classe disponible\n");
        scanf ("%d",&a.classe);
        vide_buffer();
    }
    *(compteur+a.classe-1) +=1;
        
    while (*(compteur+a.classe-1) > 1) {
        printf ("Classe déjà selectionnée par un autre joueur \nResaisir une classe disponible\n");
        scanf ("%d",&a.classe);
        vide_buffer();

        while (a.classe!=1 && a.classe!=2&& a.classe!=3 && a.classe!=4) {
            printf ("Resaisir une classe disponible\n");
            scanf ("%d",&a.classe);
            vide_buffer();
        }
    }

    
    if (a.classe==1) {
        a.classenom[0] = 'G';
        a.classenom[1] = 'U';
        a.classenom[2] = 'E';
        a.classenom[3] = 'R';
        a.classenom[4] = 'R';
        a.classenom[5] = 'I';
        a.classenom[6] = 'E';
        a.classenom[7] = 'R';
        a.classenom[8]= '\0';
    } else if (a.classe==2) {
        a.classenom[0] = 'A';
        a.classenom[1] = 'R';
        a.classenom[2] = 'C';
        a.classenom[3] = 'H';
        a.classenom[4] = 'E';
        a.classenom[5] = 'R';
        a.classenom[6]= '\0';
    } else if (a.classe==3) {
        a.classenom[0] = 'V';
        a.classenom[1] = 'O';
        a.classenom[2] = 'L';
        a.classenom[3] = 'E';
        a.classenom[4] = 'U';
        a.classenom[5] = 'R';
        a.classenom[6]= '\0';
    } else {
        a.classenom[0] = 'M';
        a.classenom[1] = 'A';
        a.classenom[2] = 'G';
        a.classenom[3] = 'I';
        a.classenom[4] = 'C';
        a.classenom[5] = 'I';
        a.classenom[6] = 'E';
        a.classenom[7] = 'N';
        a.classenom[8]= '\0';
    }

    a.etat =1; 
    a.arme = 0;
    a.killcount = 0;
    a.legendary = 0;
    a.treasure = 0;

    switch (a.classe){
        case 1 : //guerrier
            a.position.rows= 0;
            a.position.cols= 4;
            a.spawn.rows= 0;
            a.spawn.cols= 4;
            break;
        
        case 2 :
            a.position.rows= 4;
            a.position.cols= 6;
            a.spawn.rows= 4;
            a.spawn.cols= 6;
            break;
        
        case 3 :
            a.position.rows= 6;
            a.position.cols= 3;
            a.spawn.rows= 6;
            a.spawn.cols= 3;
            break;
        
        default :
            a.position.rows= 2;
            a.position.cols= 0;
            a.spawn.rows= 2;
            a.spawn.cols= 0;
            break;
    }

    printf ("%s %s a été créé\n",a.classenom, a.nom);
    
    return a;
}

#endif