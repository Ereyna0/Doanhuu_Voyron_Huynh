#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "map.h"
#include "interaction.h"


int main() {

  int n=0;
    int k;
    int i,j;
    int compteur[4]={0,0,0,0};
  srand (time (NULL));
  
  int n0 = 0, n1 = 0, n2 = 0, n3 = 0, n4 = 0, n5 = 0, n6 = 0, n7 = 0, n8 = 0, n9 = 0, n10 = 0;
  card tab[7][7];
  for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
    {
     tab[i][j].status=1; //init face ouverte
    }
    }

  for (i = 1; i < 6; i++)
    {
        for (j = 1; j < 6; j++)
    {
     tab[i][j].status=0;//init face cachée
    }
}

for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
    {
     tab[i][j].type=0;
}
}

tab[0][4].type=20; //spawn guerrier
tab[2][0].type=50; //spawn magicien
tab[4][6].type=30; // spawn archer
tab[6][3].type=40; //spawn voleur

for (i = 1; i < 6; i++)
    {
        for (j = 1; j < 6; j++)
    {
     tab[i][j].type =
       remplissage_case(&n0, &n1, &n2, &n3, &n4, &n5, &n6, &n7, &n8,
         &n9, &n10);
    }
    }
  
 
    

  
do {
        printf(" Saisir un nombre de joueurs possible (2 à 4) \n");
        scanf("%d", &n);
        vide_buffer();
    } while (n !=2 && n != 3 && n!=4);
    
    k=n-1;
    
    adventurer player[n];
    
    for (i=0;i<=k;i++) {
        player[i]=creat_player(i,&compteur[0]);
    }
  
     
    for (i=0;i<=k;i++) {
        affiche_adventurer(player[i]);
    }

affichemap2(tab);
while(player[0].etat!=2 && player[1].etat!=2 && player[3].etat!=2 && player[2].etat!=2){


for (i=0;i<=k;i++){
printf ("Tour de \033[1;36m%s\033[0m\n \n", player[i].nom);
affichemap3(&player[i], tab);
printf("\n");
  
while (player[i].etat==1){
  player[i].arme=choix_arme();
  
  directionchoix(&player[i],tab);
  affichemap3(&player[i], tab);
  printf("\n");
  interaction (&player[i], tab);
  if (player[i].etat==1&&tab[(player[i].position.rows)-1][player[i].position.cols].status!=0 && tab[(player[i].position.rows)+1][player[i].position.cols].status!=0 && tab[player[i].position.rows][player[i].position.cols-1].status!=0 && tab[player[i].position.rows][player[i].position.cols+1].status!=0) { // vérifie les cases autour du joueur 
printf("Vous êtes bloqué dans le labyrinthe. Vous êtes condamné à mourir de faim...  \n 3 Jours plus tard...");
mort(&player[i]);
} 
  if (tab[player[i].position.rows][player[i].position.cols].type>=10&&tab[player[i].position.rows][player[i].position.cols].type<=13){
    tab[player[i].position.rows][player[i].position.cols].status=2;
    }
  else {
    tab[player[i].position.rows][player[i].position.cols].status=1;
  }
  
  printf ("\n");
  affichemap3(&player[i],tab);
  printf ("\n");
  if (player[i].legendary>=1&&player[i].treasure>=1){
    player[0].etat=0; 
    player[1].etat=0;
    player[2].etat=0;
    player[3].etat=0;
    }
  

  
} 
player[i].etat=1;
if (player[i].legendary>=1&&player[i].treasure>=1){
    player[i].etat=2;
    printf("%s a gagné ! \n", player[i].nom );
}
for (int m = 1; m < 6; m++){
        for (j = 1; j < 6; j++){
            tab[m][j].status=0; //init face cachée
            }
        }

}

  
} 
affichemap(tab);
return 0;
}